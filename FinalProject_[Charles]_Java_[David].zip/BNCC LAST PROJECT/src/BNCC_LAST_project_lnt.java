import java.awt.BorderLayout;
import java.awt.Menu;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class BNCC_LAST_project_lnt {

	public BNCC_LAST_project_lnt() {
		
		new BNCC_LAST_project_lnt();
	}

	public static void main(String[] args) 
	{
		
	
        JFrame frame = new JFrame("bobacool");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);

        
        JMenuBar mb = new JMenuBar();
        JMenu m1 = new JMenu("insert menu");
        JMenu m2 = new JMenu("view menu");
        JMenu m3 = new JMenu("update menu");
        JMenu m4 = new JMenu("delete menu");
        mb.add(m1);
        mb.add(m2);
        mb.add(m3);
        mb.add(m4);
       
    
        frame.getContentPane().add(BorderLayout.NORTH, mb);
      
        frame.setVisible(true);
		
		
		ArrayList<String> arrayboba = new ArrayList<>();
		ArrayList<String> arraykode = new ArrayList<>();
		ArrayList<String> arraynama = new ArrayList<>();
		ArrayList<Integer> arrayharga = new ArrayList<>();
		ArrayList<Integer> arraystok = new ArrayList<>();
		Scanner scan = new Scanner(System.in);
		Random rand = new Random();
		String kode = "kode";
		String nama = "nama";
		int harga;
		int stok;
		int menu = 0;
		
		
		
		
		
		
		do {
			System.out.println("1.insert menu");
			System.out.println("2.view menu");
			System.out.println("3.update menu");
			System.out.println("4.delete menu");
			System.out.println("0.exit");
			System.out.println("choose: ");
			menu = scan.nextInt();scan.nextLine();
			
			
			
			switch (menu) {
			case 1:
				System.out.println("kode menu");
				String a = "BC";
				Integer c,d,e;
				c = rand.nextInt(10);
				d = rand.nextInt(10);
				e = rand.nextInt(10);
				
				
				kode = (a.toString() + '-' + c.toString() + d.toString() + e.toString());
				System.out.println("kode Menu anda adalah : " + kode);
				System.out.println("Nama Menu");
				nama = scan.nextLine();
				System.out.println("Harga Menu");
				harga = scan.nextInt();
		        System.out.println("Stok Menu");
		        stok = scan.nextInt();
		        
		        
		        
		        arraykode.add(kode);
				arraynama.add(nama);
				arrayharga.add(harga);
				arraystok.add(stok);
				arrayboba.add(kode + " " + nama  + " " + harga + " " + stok);
				System.out.println(arrayboba);
				break;
				
			case 2:
				for (int x = 0; x < arrayboba.size(); x++) {
					System.out.println(arraykode.get(x));
					System.out.println(arraynama.get(x));
					System.out.println(arrayharga.get(x));
					System.out.println(arraystok.get(x));
					
				}
				
			case 3:
				int no = 0;
				for (int x = 0; x < arrayboba.size(); x++) {
					System.out.println(arraykode.get(x));
					System.out.println(arraynama.get(x));
					System.out.println(arrayharga.get(x));
					System.out.println(arraystok.get(x));
					
					
				}
				no = scan.nextInt();scan.nextLine();
				arrayharga.get(no - 1);
				arraystok.get(no - 1);
				
				

				break;
				
			case 4:
				Integer delete = 0;
				for (int x = 0; x < arrayboba.size(); x++) {
					System.out.println(arraykode.get(x));
					System.out.println(arraynama.get(x));
					System.out.println(arrayharga.get(x));
					System.out.println(arraystok.get(x));
					
					do {
						System.out.println("input to be delete");
						delete = scan.nextInt();
						delete -= 1;
					} while (delete < 0 || delete >= arrayboba.size());
					arraykode.remove(x);
					arraynama.remove(x);
					arrayharga.remove(x);
					arraystok.remove(x);
					arrayboba.remove(x);
			}
			
			}	} while (menu != 0);}
}
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		

		

